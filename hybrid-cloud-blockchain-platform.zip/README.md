# SME Transform - Hybrid Cloud-Blockchain Platform

Enterprise-grade platform combining AI, blockchain, and cloud computing for SME digital transformation.

## Features

### 🔐 Authentication System
- Role-based access control (Admin, Manager, Analyst, Finance)
- JWT-based authentication
- Secure password hashing

### 📊 Real-Time Analytics Dashboard
- Live KPI monitoring
- Sales performance tracking
- Interactive data visualizations
- Custom reporting

### 🤖 AI-Powered Forecasting
- LSTM-based demand forecasting (85%+ accuracy)
- 6-month sales predictions
- Confidence intervals and insights
- Historical trend analysis

### 🚨 Fraud Detection
- Autoencoder/ANN models
- Real-time anomaly detection (90%+ accuracy)
- Risk scoring system
- Automated alerts

### 🔗 Blockchain Integration
- Tamper-proof audit trails
- SHA-256 encryption
- Smart contract support
- Transaction verification console

### 📤 Data Ingestion
- CSV/Excel file uploads
- Multiple data type support
- Automated blockchain stamping
- Data lake storage

## Tech Stack

### Frontend
- Next.js 16
- React 19
- TypeScript
- TailwindCSS
- Recharts
- shadcn/ui

### Backend APIs
- Next.js API Routes
- RESTful endpoints
- JWT authentication
- File processing

### ML/AI Models (Integration Ready)
- LSTM for forecasting
- Autoencoder for fraud detection
- Isolation Forest for anomaly detection

### Blockchain
- Python-based permissioned blockchain
- SHA-256 hashing
- Mock verification (production-ready architecture)

## Getting Started

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build
```

Visit `http://localhost:3000` to see the application.

## Project Structure

```
app/
├── api/              # Backend API routes
│   ├── auth/         # Authentication endpoints
│   ├── forecast/     # ML forecasting APIs
│   ├── fraud/        # Fraud detection APIs
│   ├── blockchain/   # Blockchain verification
│   └── data/         # Data ingestion
├── dashboard/        # Dashboard pages
├── login/            # Login page
├── register/         # Registration page
└── page.tsx          # Landing page

components/
├── auth/             # Auth forms
├── dashboard/        # Dashboard components
└── ui/               # UI components

```

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration

### ML & Analytics
- `GET /api/forecast/sales` - Get sales forecast
- `POST /api/fraud/detect` - Detect fraud in transaction

### Blockchain
- `POST /api/blockchain/verify` - Verify transaction on blockchain

### Data Management
- `POST /api/data/upload` - Upload and process data

## Features Roadmap

✅ Authentication & Authorization
✅ Dashboard & Analytics
✅ Sales Forecasting UI
✅ Fraud Detection Interface
✅ Blockchain Verification
✅ Data Upload System
⏳ Python ML Model Integration
⏳ Real Blockchain Network
⏳ Advanced Analytics
⏳ IoT Data Streaming

## License

Proprietary - All rights reserved
