"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function RecentActivity() {
  const activities = [
    { id: 1, type: "upload", message: "Sales data uploaded", user: "John Doe", time: "2 min ago", status: "success" },
    {
      id: 2,
      type: "blockchain",
      message: "Transaction verified on blockchain",
      user: "System",
      time: "15 min ago",
      status: "success",
    },
    {
      id: 3,
      type: "forecast",
      message: "New forecast model trained",
      user: "ML Engine",
      time: "1 hour ago",
      status: "success",
    },
    {
      id: 4,
      type: "alert",
      message: "Fraud alert triggered",
      user: "Security",
      time: "2 hours ago",
      status: "warning",
    },
    { id: 5, type: "user", message: "New user registered", user: "Jane Smith", time: "3 hours ago", status: "info" },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div
              key={activity.id}
              className="flex items-center justify-between py-3 border-b border-border last:border-0"
            >
              <div className="space-y-1">
                <p className="font-medium text-sm">{activity.message}</p>
                <p className="text-xs text-muted-foreground">
                  by {activity.user} • {activity.time}
                </p>
              </div>
              <Badge variant={activity.status === "warning" ? "destructive" : "secondary"}>{activity.status}</Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
