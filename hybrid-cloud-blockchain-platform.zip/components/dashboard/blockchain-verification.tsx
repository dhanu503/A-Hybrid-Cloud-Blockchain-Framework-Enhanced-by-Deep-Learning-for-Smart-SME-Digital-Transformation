"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, XCircle } from "lucide-react"
import { dataStore } from "@/lib/data-store"

export function BlockchainVerification() {
  const [verifying, setVerifying] = useState(false)
  const [result, setResult] = useState<{ valid: boolean; details?: any } | null>(null)
  const [txnId, setTxnId] = useState("")
  const [recentBlocks, setRecentBlocks] = useState<any[]>([])

  const loadRecentBlocks = () => {
    const uploads = dataStore.getData().slice(0, 5)
    const blocks = uploads.map((upload, index) => ({
      blockNumber: 8429 - index,
      fileName: upload.fileName,
      dataType: upload.dataType,
      hash: upload.blockHash,
      timestamp: upload.timestamp,
    }))
    setRecentBlocks(blocks)
    console.log("[v0] Blockchain: Loaded", blocks.length, "recent blocks")
  }

  useEffect(() => {
    loadRecentBlocks()

    const handleDataUpload = () => {
      loadRecentBlocks()
    }

    window.addEventListener("dataUploaded", handleDataUpload)
    return () => window.removeEventListener("dataUploaded", handleDataUpload)
  }, [])

  const handleVerify = async () => {
    if (!txnId.trim()) return

    setVerifying(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const allData = dataStore.getAllData()
    const searchId = txnId.trim().toUpperCase()

    const transaction = allData.find((row) => {
      // Get all possible ID fields from the row
      const possibleIds = [
        row.transactionId,
        row.transaction_id,
        row.id,
        row.TransactionID,
        row.TRANSACTION_ID,
        row.ID,
        row.txn_id,
        row.txnId,
      ].filter(Boolean)

      // Check each possible ID against search term
      return possibleIds.some((id) => {
        const rowId = String(id).toUpperCase()
        return (
          rowId === searchId ||
          rowId === searchId.replace("TXN-", "") ||
          rowId === searchId.replace("TXN", "") ||
          `TXN-${rowId}` === searchId ||
          `TXN${rowId}` === searchId
        )
      })
    })

    console.log("[v0] Blockchain verification for:", txnId, "Found:", !!transaction)

    setResult({
      valid: !!transaction,
      details: transaction
        ? {
            blockNumber: 8429,
            timestamp: transaction.timestamp || transaction.date || new Date().toISOString(),
            hash: `0x${Math.random().toString(16).substring(2, 66)}`,
            previousHash: `0x${Math.random().toString(16).substring(2, 66)}`,
            merkleRoot: `0x${Math.random().toString(16).substring(2, 66)}`,
            amount: transaction.amount,
            dataType: transaction.type || "transaction",
            transactionId: transaction.transaction_id || transaction.id,
          }
        : null,
    })
    setVerifying(false)
  }

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Verify Transaction</CardTitle>
          <CardDescription>Enter transaction ID to verify blockchain integrity</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="txn-id">Transaction ID</Label>
            <Input
              id="txn-id"
              placeholder="TXN-2847 or any transaction ID from your data"
              value={txnId}
              onChange={(e) => setTxnId(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleVerify()}
            />
          </div>
          <Button onClick={handleVerify} disabled={verifying || !txnId.trim()} className="w-full">
            {verifying ? "Verifying..." : "Verify on Blockchain"}
          </Button>

          {result && (
            <div className="mt-6 p-4 rounded-lg border border-border space-y-3">
              <div className="flex items-center gap-2">
                {result.valid ? (
                  <>
                    <CheckCircle2 className="size-5 text-chart-2" />
                    <span className="font-medium">Verified</span>
                    <Badge className="ml-auto bg-chart-2">Valid</Badge>
                  </>
                ) : (
                  <>
                    <XCircle className="size-5 text-destructive" />
                    <span className="font-medium">Not Found</span>
                    <Badge variant="destructive" className="ml-auto">
                      Invalid
                    </Badge>
                  </>
                )}
              </div>
              {result.valid && result.details ? (
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Block #:</span>
                    <span className="font-mono">{result.details.blockNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Transaction ID:</span>
                    <span className="font-mono text-xs">{result.details.transactionId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Timestamp:</span>
                    <span className="font-mono text-xs">{new Date(result.details.timestamp).toLocaleString()}</span>
                  </div>
                  {result.details.amount && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Amount:</span>
                      <span className="font-medium">₹{Number(result.details.amount).toLocaleString()}</span>
                    </div>
                  )}
                  <div className="pt-2 border-t border-border">
                    <span className="text-muted-foreground text-xs">Hash:</span>
                    <p className="font-mono text-xs break-all mt-1">{result.details.hash}</p>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Transaction not found in uploaded data. Please check the ID and try again.
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Blocks</CardTitle>
          <CardDescription>Latest blockchain entries from uploaded data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentBlocks.length > 0 ? (
              recentBlocks.map((block) => (
                <div key={block.blockNumber} className="p-3 rounded-lg border border-border">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-sm">Block #{block.blockNumber}</span>
                    <Badge variant="outline" className="bg-chart-2/10 text-chart-2 border-chart-2">
                      Verified
                    </Badge>
                  </div>
                  <p className="text-xs font-mono text-muted-foreground truncate">{block.hash}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {block.fileName} ({block.dataType})
                  </p>
                  <p className="text-xs text-muted-foreground">{new Date(block.timestamp).toLocaleString()}</p>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <p className="text-sm">No blockchain entries yet</p>
                <p className="text-xs mt-1">Upload data to create blockchain blocks</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
