"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Upload, FileText, CheckCircle2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { dataStore } from "@/lib/data-store"
import { formatCurrency } from "@/lib/currency"

export function DataUploadForm() {
  const { toast } = useToast()
  const [uploading, setUploading] = useState(false)
  const [dataType, setDataType] = useState("sales")
  const [file, setFile] = useState<File | null>(null)
  const [uploadResult, setUploadResult] = useState<any>(null)

  const handleUpload = async () => {
    if (!file) return

    setUploading(true)
    setUploadResult(null)

    try {
      const formData = new FormData()
      formData.append("file", file)
      formData.append("dataType", dataType)

      const response = await fetch("/api/data/upload", {
        method: "POST",
        body: formData,
      })

      const result = await response.json()

      if (response.ok) {
        setUploadResult(result)

        if (result.data) {
          dataStore.addData({
            fileName: result.fileName,
            dataType: result.dataType,
            data: result.data, // This now includes fraud fields for transactions
            timestamp: result.timestamp,
            blockHash: result.blockHash,
          })
          console.log("[v0] Data stored successfully:", result.dataType, result.data.length, "rows")
        }

        window.dispatchEvent(new CustomEvent("dataUploaded", { detail: result }))

        toast({
          title: "Upload successful",
          description: `Processed ${result.processedRows} rows from ${file.name}. Data is now available across all dashboards.`,
        })
        setFile(null)
      } else {
        toast({
          title: "Upload failed",
          description: result.error || "An error occurred during upload",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Failed to connect to server",
        variant: "destructive",
      })
    } finally {
      setUploading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Upload Business Data</CardTitle>
        <CardDescription>Upload CSV or Excel files for analysis and blockchain stamping</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="data-type">Data Type</Label>
          <Select value={dataType} onValueChange={setDataType}>
            <SelectTrigger id="data-type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sales">Sales Data</SelectItem>
              <SelectItem value="inventory">Inventory Data</SelectItem>
              <SelectItem value="transactions">Financial Transactions</SelectItem>
              <SelectItem value="customer">Customer Data</SelectItem>
              <SelectItem value="iot">IoT Sensor Data</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>File Upload</Label>
          <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
            <input
              type="file"
              id="file-upload"
              className="hidden"
              accept=".csv,.xlsx,.xls"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
            />
            <label htmlFor="file-upload" className="cursor-pointer">
              {file ? (
                <div className="flex items-center justify-center gap-2">
                  <FileText className="size-5 text-primary" />
                  <span className="text-sm">{file.name}</span>
                </div>
              ) : (
                <div className="space-y-2">
                  <Upload className="size-8 mx-auto text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">Click to upload or drag and drop</p>
                  <p className="text-xs text-muted-foreground">CSV, XLS, or XLSX (max 50MB)</p>
                </div>
              )}
            </label>
          </div>
        </div>

        {uploadResult && (
          <div className="p-4 rounded-lg border border-chart-2 bg-chart-2/10 space-y-2">
            <div className="flex items-center gap-2 text-chart-2">
              <CheckCircle2 className="size-5" />
              <span className="font-medium">Processing Complete</span>
            </div>
            <div className="text-sm space-y-1">
              <p>
                <span className="text-muted-foreground">Rows processed:</span>{" "}
                <span className="font-medium">{uploadResult.processedRows}</span>
              </p>
              <p>
                <span className="text-muted-foreground">File size:</span>{" "}
                <span className="font-medium">{(uploadResult.fileSize / 1024 / 1024).toFixed(2)} MB</span>
              </p>
              <p>
                <span className="text-muted-foreground">Data type:</span>{" "}
                <span className="font-medium">{uploadResult.dataType}</span>
              </p>
              {uploadResult.processingResults?.summary?.totalRevenue && (
                <p>
                  <span className="text-muted-foreground">Total revenue:</span>{" "}
                  <span className="font-medium">
                    {formatCurrency(uploadResult.processingResults.summary.totalRevenue)}
                  </span>
                </p>
              )}
              {uploadResult.processingResults?.summary?.flaggedTransactions && (
                <p>
                  <span className="text-muted-foreground">Flagged transactions:</span>{" "}
                  <span className="font-medium text-destructive">
                    {uploadResult.processingResults.summary.flaggedTransactions}
                  </span>
                </p>
              )}
              {uploadResult.blockchainStamped && <p className="text-chart-2 font-medium">✓ Blockchain verified</p>}
            </div>
          </div>
        )}

        <Button onClick={handleUpload} disabled={!file || uploading} className="w-full">
          {uploading ? "Uploading..." : "Upload & Process"}
        </Button>
      </CardContent>
    </Card>
  )
}
