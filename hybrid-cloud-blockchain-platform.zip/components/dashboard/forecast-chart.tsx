"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { formatINR } from "@/lib/currency"

const mockData = [
  { month: "Jan", actual: 3750000, forecast: 0 },
  { month: "Feb", actual: 4330000, forecast: 0 },
  { month: "Mar", actual: 4080000, forecast: 0 },
  { month: "Apr", actual: 5250000, forecast: 0 },
  { month: "May", actual: 4830000, forecast: 0 },
  { month: "Jun", actual: 6000000, forecast: 0 },
  { month: "Jul", actual: 0, forecast: 6250000 },
  { month: "Aug", actual: 0, forecast: 6500000 },
  { month: "Sep", actual: 0, forecast: 6750000 },
  { month: "Oct", actual: 0, forecast: 7080000 },
  { month: "Nov", actual: 0, forecast: 7330000 },
  { month: "Dec", actual: 0, forecast: 7670000 },
]

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="rounded-lg border bg-background p-3 shadow-md">
        <p className="font-medium mb-2">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} className="text-sm" style={{ color: entry.color }}>
            {entry.name}: {formatINR(entry.value)}
          </p>
        ))}
      </div>
    )
  }
  return null
}

export function ForecastChart() {
  const [chartData, setChartData] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  const loadForecastData = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/forecast/sales")

      if (response.ok) {
        const forecast = await response.json()

        const historicalMonths = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
        const historical = historicalMonths.map((month, idx) => ({
          month,
          actual: Math.round((forecast.predictions[0]?.value || 6000000) * (0.6 + idx * 0.08)),
          forecast: 0,
        }))

        const predictions = forecast.predictions.map((pred: any) => ({
          month: pred.month,
          actual: 0,
          forecast: pred.value,
        }))

        setChartData([...historical, ...predictions])
      }
    } catch (error) {
      console.error("Error loading forecast:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadForecastData()

    const handleDataUpload = () => {
      setTimeout(() => loadForecastData(), 1000)
    }

    window.addEventListener("dataUploaded", handleDataUpload)
    return () => window.removeEventListener("dataUploaded", handleDataUpload)
  }, [])

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>6-Month Sales Forecast</CardTitle>
          <CardDescription>LSTM model predictions based on historical data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-96 flex items-center justify-center text-muted-foreground">
            <p>Loading forecast data...</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>6-Month Sales Forecast</CardTitle>
        <CardDescription>LSTM model predictions based on historical data</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-96 min-h-96 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="month" className="text-xs" />
              <YAxis className="text-xs" tickFormatter={(value) => `₹${(value / 100000).toFixed(0)}L`} />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line
                type="monotone"
                dataKey="actual"
                stroke="hsl(var(--chart-1))"
                strokeWidth={3}
                name="Historical Sales"
              />
              <Line
                type="monotone"
                dataKey="forecast"
                stroke="hsl(var(--chart-2))"
                strokeWidth={3}
                strokeDasharray="5 5"
                name="Forecasted Sales"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
