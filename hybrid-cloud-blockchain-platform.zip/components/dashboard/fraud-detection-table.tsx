"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { formatINR } from "@/lib/currency"
import { useToast } from "@/hooks/use-toast"

export function FraudDetectionTable() {
  const { toast } = useToast()
  const [reviewDialog, setReviewDialog] = useState(false)
  const [selectedTxn, setSelectedTxn] = useState<any>(null)
  const [reviewDecision, setReviewDecision] = useState("approve")
  const [reviewNotes, setReviewNotes] = useState("")
  const [transactions, setTransactions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  const loadTransactionData = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/fraud/detect")

      if (response.ok) {
        const result = await response.json()
        const flaggedTxns = result.flaggedTransactions || []

        const formatted = flaggedTxns.map((txn: any) => ({
          id: String(txn.transactionId || txn.id || "N/A"),
          amount: Number(txn.amount) || 0,
          risk: txn.riskLevel || "unknown",
          score: txn.fraudScore || 0,
          time: txn.timestamp || txn.date ? new Date(txn.timestamp || txn.date).toLocaleString() : "N/A",
          user: String(txn.userId || "N/A"),
        }))

        setTransactions(formatted)
      } else {
        console.error("Failed to fetch fraud data:", response.status)
        setTransactions([])
      }
    } catch (error) {
      console.error("Error loading fraud data:", error)
      setTransactions([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadTransactionData()

    const handleDataUpload = () => {
      setTimeout(() => loadTransactionData(), 500)
    }

    window.addEventListener("dataUploaded", handleDataUpload)
    return () => window.removeEventListener("dataUploaded", handleDataUpload)
  }, [])

  const handleReview = (txn: any) => {
    setSelectedTxn(txn)
    setReviewDialog(true)
    setReviewDecision("approve")
    setReviewNotes("")
  }

  const submitReview = async () => {
    const response = await fetch("/api/fraud/review", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        transactionId: selectedTxn?.id,
        decision: reviewDecision,
        notes: reviewNotes,
        reviewedAt: new Date().toISOString(),
      }),
    })

    if (response.ok) {
      toast({
        title: "Review submitted",
        description: `Transaction ${selectedTxn?.id} has been ${reviewDecision === "approve" ? "approved" : "rejected"}`,
      })
      setReviewDialog(false)
    }
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Flagged Transactions</CardTitle>
          <CardDescription>Real-time fraud detection results</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>Loading fraud detection data...</p>
            </div>
          ) : transactions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>No flagged transactions found</p>
              <p className="text-xs mt-2">Upload transaction data to detect fraud patterns</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border text-left">
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Transaction ID</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Amount</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Risk Level</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Score</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Time</th>
                    <th className="pb-3 text-sm font-medium text-muted-foreground">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((txn) => (
                    <tr key={txn.id} className="border-b border-border last:border-0">
                      <td className="py-4 text-sm font-mono">{txn.id}</td>
                      <td className="py-4 text-sm font-medium">{formatINR(txn.amount)}</td>
                      <td className="py-4">
                        <Badge
                          variant={
                            txn.risk === "high" ? "destructive" : txn.risk === "medium" ? "secondary" : "outline"
                          }
                        >
                          {txn.risk}
                        </Badge>
                      </td>
                      <td className="py-4 text-sm">{txn.score}/100</td>
                      <td className="py-4 text-sm text-muted-foreground">{txn.time}</td>
                      <td className="py-4">
                        <Button size="sm" variant="outline" onClick={() => handleReview(txn)}>
                          Review
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={reviewDialog} onOpenChange={setReviewDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Review Transaction</DialogTitle>
            <DialogDescription>Review flagged transaction and make a decision</DialogDescription>
          </DialogHeader>

          {selectedTxn && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 p-4 rounded-lg bg-muted">
                <div>
                  <p className="text-xs text-muted-foreground">Transaction ID</p>
                  <p className="font-mono text-sm">{selectedTxn.id}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Amount</p>
                  <p className="font-medium text-sm">{formatINR(selectedTxn.amount)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Risk Score</p>
                  <p className="text-sm">{selectedTxn.score}/100</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">User</p>
                  <p className="font-mono text-sm">{selectedTxn.user}</p>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Decision</Label>
                <RadioGroup value={reviewDecision} onValueChange={setReviewDecision}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="approve" id="approve" />
                    <Label htmlFor="approve" className="font-normal">
                      Approve Transaction
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="reject" id="reject" />
                    <Label htmlFor="reject" className="font-normal">
                      Reject Transaction
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="investigate" id="investigate" />
                    <Label htmlFor="investigate" className="font-normal">
                      Needs Further Investigation
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Review Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Add any notes or comments about this transaction..."
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  rows={4}
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setReviewDialog(false)}>
              Cancel
            </Button>
            <Button onClick={submitReview}>Submit Review</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
