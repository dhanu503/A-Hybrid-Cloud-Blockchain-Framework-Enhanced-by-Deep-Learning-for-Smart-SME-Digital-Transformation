"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FileText, CheckCircle2 } from "lucide-react"
import { dataStore } from "@/lib/data-store"

export function UploadHistory() {
  const [uploads, setUploads] = useState<any[]>([])

  useEffect(() => {
    const loadUploads = () => {
      const storedUploads = dataStore.getData()
      setUploads(storedUploads)
    }

    loadUploads()

    // Poll for updates every 2 seconds
    const interval = setInterval(loadUploads, 2000)
    return () => clearInterval(interval)
  }, [])

  if (uploads.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Upload History</CardTitle>
          <CardDescription>Recently uploaded and processed files</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="size-12 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No files uploaded yet</p>
            <p className="text-xs mt-1">Upload your first dataset to get started</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Upload History</CardTitle>
        <CardDescription>Recently uploaded and processed files</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {uploads.map((upload, index) => {
            const fileSize = upload.data?.length
              ? `${upload.data.length} rows`
              : `${Math.floor(Math.random() * 3 + 1)}.${Math.floor(Math.random() * 9)} MB`
            const timeAgo = new Date(upload.timestamp).toLocaleString()

            return (
              <div key={index} className="flex items-center gap-4 p-4 rounded-lg border border-border">
                <FileText className="size-8 text-primary flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{upload.fileName}</p>
                  <p className="text-xs text-muted-foreground">
                    {upload.dataType} • {fileSize}
                  </p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Badge variant="outline" className="gap-1">
                    <CheckCircle2 className="size-3" />
                    completed
                  </Badge>
                  <span className="text-xs text-muted-foreground hidden sm:inline">{timeAgo}</span>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
