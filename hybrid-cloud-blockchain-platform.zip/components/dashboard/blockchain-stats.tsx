"use client"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Lock, Hash, Blocks, Clock } from "lucide-react"

export function BlockchainStats() {
  const stats = [
    {
      title: "Total Blocks",
      value: "8,429",
      icon: Blocks,
      color: "text-chart-1",
    },
    {
      title: "Verified Transactions",
      value: "124,847",
      icon: Lock,
      color: "text-chart-2",
    },
    {
      title: "Average Block Time",
      value: "2.4s",
      icon: Clock,
      color: "text-chart-3",
    },
    {
      title: "Chain Integrity",
      value: "100%",
      icon: Hash,
      color: "text-chart-4",
    },
  ]

  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        return (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
              <Icon className={cn("size-4", stat.color)} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(" ")
}
