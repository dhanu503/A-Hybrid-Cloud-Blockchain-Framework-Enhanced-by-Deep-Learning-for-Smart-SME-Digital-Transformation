"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const data = [
  { hour: "00:00", high: 2, medium: 5, low: 18 },
  { hour: "04:00", high: 1, medium: 3, low: 12 },
  { hour: "08:00", high: 4, medium: 8, low: 24 },
  { hour: "12:00", high: 6, medium: 12, low: 32 },
  { hour: "16:00", high: 3, medium: 9, low: 28 },
  { hour: "20:00", high: 2, medium: 6, low: 21 },
]

export function FraudScoreChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Risk Distribution by Hour</CardTitle>
        <CardDescription>Transaction risk levels throughout the day</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="hour" className="text-xs" />
              <YAxis className="text-xs" />
              <Tooltip />
              <Bar dataKey="high" fill="hsl(var(--destructive))" name="High Risk" />
              <Bar dataKey="medium" fill="hsl(var(--chart-4))" name="Medium Risk" />
              <Bar dataKey="low" fill="hsl(var(--chart-2))" name="Low Risk" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
