"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, AlertCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { dataStore } from "@/lib/data-store"

export function FraudAlerts() {
  const [alerts, setAlerts] = useState([
    {
      id: 1,
      type: "high",
      title: "Unusual Transaction Pattern",
      description: "Transaction #TXN-2847",
      time: "5 min ago",
    },
    {
      id: 2,
      type: "medium",
      title: "Multiple Failed Login Attempts",
      description: "User ID: user_8472",
      time: "23 min ago",
    },
    {
      id: 3,
      type: "high",
      title: "Large Amount Transfer",
      description: "Transaction #TXN-2839",
      time: "1 hour ago",
    },
  ])

  useEffect(() => {
    const transactionData = dataStore.getTransactionData()

    if (transactionData.length > 0) {
      const flaggedTransactions = transactionData
        .filter((row) => {
          const amount = Number.parseFloat(row.amount || 0)
          return amount > 500000
        })
        .slice(0, 5)
        .map((row, index) => ({
          id: index + 1,
          type: Number.parseFloat(row.amount || 0) > 1000000 ? "high" : "medium",
          title: `Large Amount Transfer Detected`,
          description: `Transaction ID: ${row.transaction_id || row.id || `TXN-${index + 1000}`}`,
          time: row.timestamp || row.date || "Recently",
        }))

      if (flaggedTransactions.length > 0) {
        setAlerts(flaggedTransactions)
      }
    }
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="size-5 text-destructive" />
          Fraud Alerts
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {alerts.map((alert) => (
          <div key={alert.id} className="flex items-start gap-3 p-3 rounded-lg border border-border">
            <AlertCircle
              className={cn("size-5 mt-0.5", alert.type === "high" ? "text-destructive" : "text-yellow-500")}
            />
            <div className="flex-1 space-y-1">
              <div className="flex items-start justify-between gap-2">
                <p className="font-medium text-sm">{alert.title}</p>
                <Badge variant={alert.type === "high" ? "destructive" : "secondary"} className="text-xs">
                  {alert.type}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground">{alert.description}</p>
              <p className="text-xs text-muted-foreground">{alert.time}</p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(" ")
}
