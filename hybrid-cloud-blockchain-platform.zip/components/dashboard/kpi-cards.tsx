"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { TrendingUp, TrendingDown, DollarSign, ShoppingCart, Users, Package } from "lucide-react"
import { formatINR } from "@/lib/currency"
import { dataStore } from "@/lib/data-store"

export function KPICards() {
  const [kpis, setKpis] = useState({
    revenue: 23750000,
    orders: 1284,
    customers: 847,
    inventory: 3429,
  })

  useEffect(() => {
    const salesData = dataStore.getSalesData()
    const transactionData = dataStore.getTransactionData()

    if (salesData.length > 0) {
      const totalRevenue = salesData.reduce((sum, row) => {
        const amount = Number.parseFloat(row.amount || row.revenue || row.sales || 0)
        return sum + (isNaN(amount) ? 0 : amount)
      }, 0)

      const totalOrders = salesData.length

      const uniqueCustomers = new Set(salesData.map((row) => row.customer_id || row.customerId || row.user_id)).size

      setKpis((prev) => ({
        ...prev,
        revenue: totalRevenue,
        orders: totalOrders,
        customers: uniqueCustomers > 0 ? uniqueCustomers : prev.customers,
      }))
    } else if (transactionData.length > 0) {
      const totalRevenue = transactionData.reduce((sum, row) => {
        const amount = Number.parseFloat(row.amount || 0)
        return sum + (isNaN(amount) ? 0 : amount)
      }, 0)

      setKpis((prev) => ({
        ...prev,
        revenue: totalRevenue,
        orders: transactionData.length,
      }))
    }
  }, [])

  const kpiData = [
    {
      title: "Total Revenue",
      value: formatINR(kpis.revenue),
      change: "+12.5%",
      trend: "up",
      icon: DollarSign,
      color: "text-chart-1",
    },
    {
      title: "Total Orders",
      value: kpis.orders.toLocaleString(),
      change: "+8.2%",
      trend: "up",
      icon: ShoppingCart,
      color: "text-chart-2",
    },
    {
      title: "Active Customers",
      value: kpis.customers.toLocaleString(),
      change: "+5.1%",
      trend: "up",
      icon: Users,
      color: "text-chart-3",
    },
    {
      title: "Inventory Items",
      value: kpis.inventory.toLocaleString(),
      change: "-2.4%",
      trend: "down",
      icon: Package,
      color: "text-chart-4",
    },
  ]

  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {kpiData.map((kpi) => {
        const Icon = kpi.icon
        const TrendIcon = kpi.trend === "up" ? TrendingUp : TrendingDown
        return (
          <Card key={kpi.title}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <p className="text-sm font-medium text-muted-foreground">{kpi.title}</p>
              <Icon className={cn("size-4", kpi.color)} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{kpi.value}</div>
              <div
                className={cn(
                  "text-xs flex items-center gap-1 mt-1",
                  kpi.trend === "up" ? "text-chart-1" : "text-destructive",
                )}
              >
                <TrendIcon className="size-3" />
                {kpi.change} from last month
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(" ")
}
