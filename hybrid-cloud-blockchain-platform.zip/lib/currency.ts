export function formatINR(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount)
}

export const formatCurrency = formatINR

export function parseINR(value: string): number {
  return Number.parseFloat(value.replace(/[₹,]/g, ""))
}
