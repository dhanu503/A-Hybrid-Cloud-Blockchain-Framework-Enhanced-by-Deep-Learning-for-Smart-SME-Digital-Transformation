interface UploadedData {
  fileName: string
  dataType: string
  data: any[]
  timestamp: string
  blockHash: string
}

class DataStore {
  private static instance: DataStore
  private data: UploadedData[] = []

  private constructor() {
    // Load from localStorage on initialization
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("sme_uploaded_data")
      if (stored) {
        try {
          this.data = JSON.parse(stored)
        } catch (e) {
          console.error("[v0] Failed to load stored data:", e)
        }
      }
    }
  }

  static getInstance(): DataStore {
    if (!DataStore.instance) {
      DataStore.instance = new DataStore()
    }
    return DataStore.instance
  }

  addData(upload: UploadedData) {
    this.data.unshift(upload)
    if (this.data.length > 50) this.data = this.data.slice(0, 50) // Keep last 50 uploads
    this.persist()
  }

  getData(): UploadedData[] {
    return this.data
  }

  getLatestByType(dataType: string): UploadedData | null {
    return this.data.find((d) => d.dataType === dataType) || null
  }

  getSalesData(): any[] {
    const salesUpload = this.getLatestByType("sales")
    return salesUpload?.data || []
  }

  getTransactionData(): any[] {
    const txUploads = this.data.filter((d) => d.dataType === "transactions")
    const allTxData = txUploads.flatMap((upload) => upload.data)
    return allTxData
  }

  getAllData(): any[] {
    return this.data.flatMap((d) => d.data || [])
  }

  private persist() {
    if (typeof window !== "undefined") {
      localStorage.setItem("sme_uploaded_data", JSON.stringify(this.data))
    }
  }

  clear() {
    this.data = []
    this.persist()
  }
}

export const dataStore = DataStore.getInstance()
