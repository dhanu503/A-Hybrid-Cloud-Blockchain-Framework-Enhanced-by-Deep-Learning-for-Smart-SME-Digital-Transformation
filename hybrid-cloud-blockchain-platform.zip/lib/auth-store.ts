// Simple user authentication storage using localStorage
// For production, replace with database integration (Supabase, Neon, etc.)

export interface User {
  id: string
  email: string
  name: string
  company: string
  role: string
  password: string // In production, this should be hashed
  createdAt: string
}

export interface Session {
  userId: string
  token: string
  expiresAt: number
}

class AuthStore {
  private readonly USERS_KEY = "hybrid_cloud_users"
  private readonly SESSIONS_KEY = "hybrid_cloud_sessions"

  // Get all users
  getUsers(): User[] {
    if (typeof window === "undefined") return []
    const users = localStorage.getItem(this.USERS_KEY)
    return users ? JSON.parse(users) : []
  }

  // Save users
  private saveUsers(users: User[]): void {
    if (typeof window === "undefined") return
    localStorage.setItem(this.USERS_KEY, JSON.stringify(users))
  }

  // Get user by email
  getUserByEmail(email: string): User | null {
    const users = this.getUsers()
    return users.find((u) => u.email.toLowerCase() === email.toLowerCase()) || null
  }

  // Register new user
  registerUser(userData: Omit<User, "id" | "createdAt">): { success: boolean; user?: User; error?: string } {
    const users = this.getUsers()

    // Check if email already exists
    if (this.getUserByEmail(userData.email)) {
      return { success: false, error: "Email already registered" }
    }

    // Validate password strength
    if (userData.password.length < 8) {
      return { success: false, error: "Password must be at least 8 characters long" }
    }

    // Create new user
    const newUser: User = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    }

    users.push(newUser)
    this.saveUsers(users)

    return { success: true, user: newUser }
  }

  // Validate login credentials
  validateLogin(email: string, password: string): { success: boolean; user?: User; error?: string } {
    const user = this.getUserByEmail(email)

    if (!user) {
      return { success: false, error: "Invalid email or password" }
    }

    if (user.password !== password) {
      return { success: false, error: "Invalid email or password" }
    }

    return { success: true, user }
  }

  // Create session
  createSession(userId: string): string {
    const token = `token_${userId}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const session: Session = {
      userId,
      token,
      expiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
    }

    if (typeof window !== "undefined") {
      const sessions = this.getSessions()
      sessions.push(session)
      localStorage.setItem(this.SESSIONS_KEY, JSON.stringify(sessions))
    }

    return token
  }

  // Get sessions
  private getSessions(): Session[] {
    if (typeof window === "undefined") return []
    const sessions = localStorage.getItem(this.SESSIONS_KEY)
    return sessions ? JSON.parse(sessions) : []
  }

  // Validate session
  validateSession(token: string): User | null {
    const sessions = this.getSessions()
    const session = sessions.find((s) => s.token === token && s.expiresAt > Date.now())

    if (!session) return null

    const users = this.getUsers()
    return users.find((u) => u.id === session.userId) || null
  }

  // Clear expired sessions
  clearExpiredSessions(): void {
    if (typeof window === "undefined") return
    const sessions = this.getSessions()
    const validSessions = sessions.filter((s) => s.expiresAt > Date.now())
    localStorage.setItem(this.SESSIONS_KEY, JSON.stringify(validSessions))
  }
}

export const authStore = new AuthStore()
