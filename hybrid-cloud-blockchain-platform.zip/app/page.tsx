import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, TrendingUp, Lock, Zap, BarChart3 } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="size-8 rounded-lg bg-primary flex items-center justify-center">
              <Shield className="size-5 text-primary-foreground" />
            </div>
            <span className="font-semibold text-xl">SME Transform</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="ghost">Login</Button>
            </Link>
            <Link href="/register">
              <Button>Get Started</Button>
            </Link>
          </nav>
        </div>
      </header>

      <main>
        {/* Hero */}
        <section className="container mx-auto px-4 py-24 text-center">
          <div className="max-w-3xl mx-auto space-y-6">
            <h1 className="text-5xl font-bold tracking-tight text-balance">
              Transform Your Business with AI & Blockchain
            </h1>
            <p className="text-xl text-muted-foreground text-pretty">
              Enterprise-grade hybrid cloud platform combining deep learning, blockchain security, and real-time
              analytics for SME digital transformation
            </p>
            <div className="flex gap-4 justify-center pt-4">
              <Link href="/register">
                <Button size="lg" className="gap-2">
                  <Zap className="size-4" />
                  Start Free Trial
                </Button>
              </Link>
              <Link href="/login">
                <Button size="lg" variant="outline">
                  View Demo
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="container mx-auto px-4 py-16">
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <div className="size-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <TrendingUp className="size-6 text-primary" />
                </div>
                <CardTitle>AI-Powered Forecasting</CardTitle>
                <CardDescription>
                  LSTM-based demand forecasting with 85%+ accuracy for inventory and sales optimization
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <div className="size-12 rounded-lg bg-chart-2/20 flex items-center justify-center mb-4">
                  <Lock className="size-6 text-chart-2" />
                </div>
                <CardTitle>Blockchain Security</CardTitle>
                <CardDescription>
                  Tamper-proof audit trails with smart contract automation and SHA-256 encryption
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <div className="size-12 rounded-lg bg-chart-3/20 flex items-center justify-center mb-4">
                  <BarChart3 className="size-6 text-chart-3" />
                </div>
                <CardTitle>Real-Time Analytics</CardTitle>
                <CardDescription>
                  Interactive dashboards with fraud detection, anomaly alerts, and operational KPIs
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </section>

        {/* Stats */}
        <section className="border-y border-border bg-muted/30 py-16">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-4 gap-8 text-center">
              <div>
                <div className="text-4xl font-bold text-primary">90%</div>
                <div className="text-sm text-muted-foreground mt-1">Faster Reporting</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-chart-2">2×</div>
                <div className="text-sm text-muted-foreground mt-1">Processing Speed</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-chart-3">95%</div>
                <div className="text-sm text-muted-foreground mt-1">System Uptime</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-chart-4">85%+</div>
                <div className="text-sm text-muted-foreground mt-1">Forecast Accuracy</div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="container mx-auto px-4 py-24 text-center">
          <div className="max-w-2xl mx-auto space-y-6">
            <h2 className="text-4xl font-bold text-balance">Ready to Transform Your Business?</h2>
            <p className="text-lg text-muted-foreground">
              Join leading SMEs leveraging AI and blockchain for digital transformation
            </p>
            <Link href="/register">
              <Button size="lg">Get Started Today</Button>
            </Link>
          </div>
        </section>
      </main>

      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          © 2025 SME Transform. Hybrid Cloud-Blockchain Platform.
        </div>
      </footer>
    </div>
  )
}
