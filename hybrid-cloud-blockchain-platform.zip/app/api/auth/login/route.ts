import { NextResponse } from "next/server"

// Kept for backward compatibility but returns a message
export async function POST(request: Request) {
  return NextResponse.json(
    {
      error: "Authentication is handled client-side. This endpoint is deprecated.",
    },
    { status: 400 },
  )
}
