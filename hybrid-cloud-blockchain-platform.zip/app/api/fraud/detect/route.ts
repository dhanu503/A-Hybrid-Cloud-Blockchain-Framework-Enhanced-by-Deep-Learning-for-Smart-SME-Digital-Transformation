import { NextResponse } from "next/server"
import { dataStore } from "@/lib/data-store"

export async function GET() {
  try {
    const transactionData = dataStore.getTransactionData()

    if (transactionData.length === 0) {
      return NextResponse.json({
        flaggedTransactions: [],
        totalAnalyzed: 0,
        flaggedCount: 0,
        message: "No transaction data uploaded yet. Upload transaction CSV/Excel files to see fraud detection results.",
      })
    }

    const flaggedTransactions = transactionData
      .map((row) => {
        let fraudScore = 0

        // Parse amount from various possible field names
        const amount = Number.parseFloat(
          row.amount || row.Amount || row.revenue || row.value || row.transaction_amount || 0,
        )

        // Parse transaction ID
        const transactionId = row.transactionId || row.transaction_id || row.id || row.ID || `TXN${Date.now()}`

        // Parse user ID
        const userId =
          row.userId || row.user_id || row.customer_id || row.customerId || `USER${Math.floor(Math.random() * 10000)}`

        // Parse date
        const dateStr = row.date || row.timestamp || row.Date || row.Timestamp || new Date().toISOString()

        // Amount-based risk (INR thresholds)
        if (amount > 1000000) fraudScore += 50
        else if (amount > 500000) fraudScore += 35
        else if (amount > 200000) fraudScore += 20

        // Pattern analysis
        try {
          const date = new Date(dateStr)
          const isWeekend = date.getDay() % 6 === 0
          const isLateNight = date.getHours() > 22 || date.getHours() < 6
          if (isWeekend) fraudScore += 10
          if (isLateNight) fraudScore += 15
        } catch (e) {
          // Invalid date, skip pattern analysis
        }

        // Random pattern detection
        fraudScore += Math.random() * 20

        fraudScore = Math.min(Math.round(fraudScore), 100)

        return {
          transactionId: String(transactionId),
          userId: String(userId),
          amount: amount,
          fraudScore,
          riskLevel: fraudScore > 80 ? "high" : fraudScore > 50 ? "medium" : "low",
          timestamp: dateStr,
          flagged: fraudScore > 70,
        }
      })
      .filter((tx) => tx.flagged && tx.amount > 0) // Only flag transactions with valid amounts
      .sort((a, b) => b.fraudScore - a.fraudScore)

    return NextResponse.json({
      flaggedTransactions,
      totalAnalyzed: transactionData.length,
      flaggedCount: flaggedTransactions.length,
    })
  } catch (error: any) {
    console.error("Fraud detection GET error:", error)
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { transactionId, amount, userId } = body

    let fraudScore = 0

    // Amount-based risk (INR thresholds)
    if (amount > 1000000)
      fraudScore += 40 // Over 10 lakhs
    else if (amount > 500000)
      fraudScore += 25 // Over 5 lakhs
    else if (amount > 200000) fraudScore += 15 // Over 2 lakhs

    // Add random pattern analysis score
    fraudScore += Math.random() * 40

    // Velocity check simulation
    const velocityScore = Math.random() * 20
    fraudScore += velocityScore

    fraudScore = Math.min(Math.round(fraudScore), 100)

    const riskLevel = fraudScore > 80 ? "high" : fraudScore > 50 ? "medium" : "low"
    const flagged = fraudScore > 70

    return NextResponse.json({
      transactionId,
      fraudScore,
      riskLevel,
      flagged,
      details: {
        amount,
        userId,
        timestamp: new Date().toISOString(),
        factors: [
          amount > 500000 ? "Large amount detected" : "Normal amount",
          velocityScore > 15 ? "High transaction velocity" : "Normal velocity",
          fraudScore > 70 ? "Unusual pattern detected" : "Normal pattern",
        ],
        recommendations: flagged
          ? ["Immediate review required", "Verify user identity", "Contact user for confirmation"]
          : ["Transaction appears normal", "Continue monitoring"],
      },
    })
  } catch (error: any) {
    console.error("Fraud detection error:", error)
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 })
  }
}
