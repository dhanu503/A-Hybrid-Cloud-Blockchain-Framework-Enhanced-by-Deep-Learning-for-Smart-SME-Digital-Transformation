import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { transactionId, decision, notes, reviewedAt } = body

    // In production, save review to database
    // For now, return success response

    return NextResponse.json({
      success: true,
      transactionId,
      decision,
      reviewedAt,
      reviewedBy: "current_user",
    })
  } catch (error) {
    console.error("Review error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
