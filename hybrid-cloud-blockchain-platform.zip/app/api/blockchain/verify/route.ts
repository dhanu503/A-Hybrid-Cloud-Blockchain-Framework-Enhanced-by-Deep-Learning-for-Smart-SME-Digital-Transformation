import { NextResponse } from "next/server"
import { createHash } from "crypto"
import { dataStore } from "@/lib/data-store"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const transactionId = searchParams.get("transactionId")

    if (!transactionId) {
      return NextResponse.json({ error: "Transaction ID required" }, { status: 400 })
    }

    const allData = dataStore.getAllData()
    const transaction = allData.find(
      (row) => row.transactionId === transactionId || row.transaction_id === transactionId || row.id === transactionId,
    )

    if (!transaction) {
      return NextResponse.json(
        {
          valid: false,
          transactionId,
          error: "Transaction not found in blockchain",
          message: "This transaction ID does not exist in the uploaded data",
        },
        { status: 404 },
      )
    }

    const hash = createHash("sha256")
      .update(JSON.stringify({ transactionId, data: transaction, timestamp: Date.now() }))
      .digest("hex")

    const blockNumber = Math.floor(Math.random() * 10000) + 8000

    return NextResponse.json({
      valid: true,
      transactionId,
      blockNumber,
      hash: `0x${hash}`,
      timestamp: transaction.date || new Date().toISOString(),
      verified: true,
      transactionData: {
        amount: transaction.amount,
        userId: transaction.userId,
        date: transaction.date,
      },
    })
  } catch (error: any) {
    console.error("Blockchain verify GET error:", error)
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { transactionId, data } = body

    // Mock blockchain verification - replace with real blockchain logic
    const hash = createHash("sha256")
      .update(JSON.stringify({ transactionId, data, timestamp: Date.now() }))
      .digest("hex")

    return NextResponse.json({
      valid: true,
      transactionId,
      blockNumber: Math.floor(Math.random() * 10000) + 8000,
      hash: `0x${hash}`,
      timestamp: new Date().toISOString(),
      verified: true,
    })
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
