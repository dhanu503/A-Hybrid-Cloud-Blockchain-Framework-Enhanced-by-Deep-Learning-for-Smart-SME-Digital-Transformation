"use client"

import { useEffect, useState } from "react"
import { DashboardShell } from "@/components/dashboard/shell"
import { BlockchainVerification } from "@/components/dashboard/blockchain-verification"
import { BlockchainStats } from "@/components/dashboard/blockchain-stats"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Lock } from "lucide-react"

export default function BlockchainPage() {
  const [dataVersion, setDataVersion] = useState(0)

  useEffect(() => {
    const handleDataUpload = () => {
      console.log("[v0] Blockchain page: New data uploaded, refreshing...")
      setDataVersion((v) => v + 1)
    }

    window.addEventListener("dataUploaded", handleDataUpload)
    return () => window.removeEventListener("dataUploaded", handleDataUpload)
  }, [])

  return (
    <DashboardShell>
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-bold">Blockchain Verification</h1>
            <p className="text-muted-foreground">Tamper-proof audit trails with SHA-256 encryption</p>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Lock className="size-4 text-chart-3" />
            Permissioned Network
          </div>
        </div>

        <BlockchainStats key={dataVersion} />
        <BlockchainVerification key={dataVersion} />

        <Card>
          <CardHeader>
            <CardTitle>How It Works</CardTitle>
            <CardDescription>Understanding blockchain verification</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="size-8 rounded-full bg-chart-1/20 flex items-center justify-center flex-shrink-0">
                <span className="text-xs font-bold text-chart-1">1</span>
              </div>
              <div>
                <p className="font-medium">Data Hashing</p>
                <p className="text-sm text-muted-foreground">Every transaction is hashed using SHA-256 algorithm</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="size-8 rounded-full bg-chart-2/20 flex items-center justify-center flex-shrink-0">
                <span className="text-xs font-bold text-chart-2">2</span>
              </div>
              <div>
                <p className="font-medium">Block Creation</p>
                <p className="text-sm text-muted-foreground">
                  Hashes are added to blocks with timestamps and previous block reference
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="size-8 rounded-full bg-chart-3/20 flex items-center justify-center flex-shrink-0">
                <span className="text-xs font-bold text-chart-3">3</span>
              </div>
              <div>
                <p className="font-medium">Immutable Chain</p>
                <p className="text-sm text-muted-foreground">
                  Any tampering breaks the chain making it immediately detectable
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}
