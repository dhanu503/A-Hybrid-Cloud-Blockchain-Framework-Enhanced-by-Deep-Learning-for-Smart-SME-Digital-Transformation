"use client"

import { useEffect, useState } from "react"
import { DashboardShell } from "@/components/dashboard/shell"
import { ForecastChart } from "@/components/dashboard/forecast-chart"
import { ForecastMetrics } from "@/components/dashboard/forecast-metrics"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp } from "lucide-react"

export default function ForecastPage() {
  const [dataVersion, setDataVersion] = useState(0)

  useEffect(() => {
    const handleDataUpload = () => {
      console.log("[v0] Forecast page: New data uploaded, refreshing...")
      setDataVersion((v) => v + 1)
    }

    window.addEventListener("dataUploaded", handleDataUpload)
    return () => window.removeEventListener("dataUploaded", handleDataUpload)
  }, [])

  return (
    <DashboardShell>
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-bold">Sales Forecasting</h1>
            <p className="text-muted-foreground">LSTM-based demand forecasting with 85%+ accuracy</p>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <TrendingUp className="size-4 text-chart-1" />
            Model: LSTM v2.1
          </div>
        </div>

        <ForecastMetrics key={dataVersion} />
        <ForecastChart key={dataVersion} />

        <Card>
          <CardHeader>
            <CardTitle>Forecast Insights</CardTitle>
            <CardDescription>Key predictions and recommendations</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="size-2 rounded-full bg-chart-1 mt-2" />
              <div>
                <p className="font-medium">Peak demand expected next month</p>
                <p className="text-sm text-muted-foreground">Increase inventory by 15% to meet projected demand</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="size-2 rounded-full bg-chart-2 mt-2" />
              <div>
                <p className="font-medium">Seasonal trend detected</p>
                <p className="text-sm text-muted-foreground">
                  Q2 typically shows 20% growth - prepare resources accordingly
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="size-2 rounded-full bg-chart-3 mt-2" />
              <div>
                <p className="font-medium">Model confidence: 87%</p>
                <p className="text-sm text-muted-foreground">High accuracy based on 2 years of historical data</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}
