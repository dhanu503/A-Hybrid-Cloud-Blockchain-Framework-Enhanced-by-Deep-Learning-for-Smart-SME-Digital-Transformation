"use client"

import { useEffect, useState } from "react"
import { DashboardShell } from "@/components/dashboard/shell"
import { KPICards } from "@/components/dashboard/kpi-cards"
import { SalesChart } from "@/components/dashboard/sales-chart"
import { FraudAlerts } from "@/components/dashboard/fraud-alerts"
import { RecentActivity } from "@/components/dashboard/recent-activity"

export default function DashboardPage() {
  const [dataVersion, setDataVersion] = useState(0)

  useEffect(() => {
    const handleDataUpload = () => {
      setDataVersion((v) => v + 1)
    }

    window.addEventListener("dataUploaded", handleDataUpload)
    return () => window.removeEventListener("dataUploaded", handleDataUpload)
  }, [])

  return (
    <DashboardShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Real-time analytics and business insights</p>
        </div>

        <KPICards key={dataVersion} />

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <SalesChart key={dataVersion} />
          </div>
          <div>
            <FraudAlerts key={dataVersion} />
          </div>
        </div>

        <RecentActivity key={dataVersion} />
      </div>
    </DashboardShell>
  )
}
