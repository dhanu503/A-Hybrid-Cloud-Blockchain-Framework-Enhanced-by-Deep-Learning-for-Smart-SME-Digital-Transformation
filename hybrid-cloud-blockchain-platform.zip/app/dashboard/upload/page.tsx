import { DashboardShell } from "@/components/dashboard/shell"
import { DataUploadForm } from "@/components/dashboard/data-upload-form"
import { UploadHistory } from "@/components/dashboard/upload-history"

export const metadata = {
  title: "Data Upload | SME Transform",
  description: "Upload and ingest business data",
}

export default function UploadPage() {
  return (
    <DashboardShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Data Upload</h1>
          <p className="text-muted-foreground">Upload sales, inventory, or transaction data for analysis</p>
        </div>

        <DataUploadForm />
        <UploadHistory />
      </div>
    </DashboardShell>
  )
}
